package com.example.kursova_train_003;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;

public class Headmenu_Controller {


    @FXML
    private Button btnALog_into;

    @FXML
    private Button btnHAutorization;

    @FXML
    private Button btnHRegister;

    @FXML
    private Button btnRCreate_acc;

    @FXML
    private Pane pane_create;

    @FXML
    private Pane pane_register;

    @FXML
    private TextField tALogin;

    @FXML
    private TextField tApassword;

    @FXML
    private Label tLAWarning;

    @FXML
    private TextField tRFatherName;

    @FXML
    private TextField tRFirstName;

    @FXML
    private TextField tRLastName;

    @FXML
    private TextField tRLogin;

    @FXML
    private TextField tRNuberPhone;

    @FXML
    private TextField tRPassword;

    @FXML
    void btnALog_intoA(ActionEvent event) {

    }

    @FXML
    void btnHAutorizationA(ActionEvent event) {
        pane_create.setVisible(false);
        pane_register.setVisible(true);
        btnHAutorization.setDisable(true);
        btnHRegister.setDisable(false);
    }

    @FXML
    void btnHRegisterA(ActionEvent event) {
        pane_create.setVisible(true);
        pane_register.setVisible(false);
        btnHRegister.setDisable(true);
        btnHAutorization.setDisable(false);
    }

    @FXML
    void btnRCreate_accA(ActionEvent event) {

    }

}
